// app.js

document.addEventListener('DOMContentLoaded', function() {
    const userList = document.getElementById('user-list');
    const userForm = document.getElementById('user-form');
    const userIdInput = document.getElementById('user-id');
    const userNameInput = document.getElementById('user-name');
    const userEmailInput = document.getElementById('user-email');
    const userImageInput = document.getElementById('user-image');
    const logoutButton = document.getElementById('logout-button');

    // Check if the user is logged in
    fetch('api.php?action=checkSession')
        .then(response => response.json())
        .then(data => {
            if (!data.loggedIn) {
                alert('Veuillez vous connecter pour accéder à cette page.');
                window.location.href = 'login.html';
            } else {
                userForm.style.display = 'block';
                logoutButton.style.display = 'block';
            }
        });

    // Logout
    logoutButton.addEventListener('click', function() {
        fetch('logout.php')
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    alert('Déconnexion réussie.');
                    window.location.href = 'login.html';
                }
            });
    });

    // Fetch users and update the list
    function fetchUsers() {
        fetch('api.php?action=read')
            .then(response => response.json())
            .then(data => {
                userList.innerHTML = '';
                data.forEach(user => {
                    const li = document.createElement('li');

                    const img = document.createElement('img');
                    img.src = user.image ? user.image : 'placeholder.jpg';
                    li.appendChild(img);

                    li.appendChild(document.createTextNode(`${user.name} (${user.email})`));

                    const editButton = document.createElement('button');
                    editButton.textContent = 'Modifier';
                    editButton.onclick = () => {
                        userIdInput.value = user.id;
                        userNameInput.value = user.name;
                        userEmailInput.value = user.email;
                        userImageInput.value = '';
                    };
                    li.appendChild(editButton);

                    const deleteButton = document.createElement('button');
                    deleteButton.textContent = 'Supprimer';
                    deleteButton.onclick = () => deleteUser(user.id);
                    li.appendChild(deleteButton);

                    userList.appendChild(li);
                });
            });
    }

    fetchUsers();

    // Nouveau
    document.getElementById('add-button').addEventListener('click', function() {
        const formData = new FormData();
        formData.append('name', userNameInput.value);
        formData.append('email', userEmailInput.value);
        if (userImageInput.files[0]) {
            formData.append('image', userImageInput.files[0]);
        }

        fetch('api.php?action=create', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                fetchUsers();
                userForm.reset();
            } else {
                alert('Erreur lors de l\'ajout de l\'utilisateur.');
            }
        });
    });

    // Mis a jour
    document.getElementById('update-button').addEventListener('click', function() {
        const formData = new FormData();
        formData.append('id', userIdInput.value);
        formData.append('name', userNameInput.value);
        formData.append('email', userEmailInput.value);
        if (userImageInput.files[0]) {
            formData.append('image', userImageInput.files[0]);
        }

        fetch('api.php?action=update', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                fetchUsers();
                userForm.reset();
            } else {
                alert('Erreur lors de la mise à jour de l\'utilisateur.');
            }
        });
    });

    // Supprimer
    function deleteUser(id) {
        if (confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?')) {
            fetch(`api.php?action=delete&id=${id}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        fetchUsers();
                    } else {
                        alert('Erreur lors de la suppression de l\'utilisateur.');
                    }
                });
        }
    }
});
