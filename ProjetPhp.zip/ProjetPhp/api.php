<?php

header('Content-Type: application/json');
session_start();

$action = $_GET['action'] ?? '';
$data = json_decode(file_get_contents('php://input'), true);
$userFile = 'users.json';

function readData($file) {
    if (!file_exists($file)) {
        return [];
    }
    return json_decode(file_get_contents($file), true);
}

function writeData($file, $data) {
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
}

function getUserByEmail($email) {
    global $userFile;
    $users = readData($userFile);
    foreach ($users as $user) {
        if ($user['email'] === $email) {
            return $user;
        }
    }
    return null;
}

switch ($action) {
    case 'register':
        $users = readData($userFile);
        
        // Check if the user already exists
        if (getUserByEmail($data['email'])) {
            echo json_encode(['success' => false, 'message' => 'Utilisateur déjà existant.']);
            break;
        }
        
        // Hash the password before storing it
        $newUser = [
            'id' => uniqid(),
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => password_hash($data['password'], PASSWORD_BCRYPT)  // Use password_hash
        ];

        // Add the new user to the list
        $users[] = $newUser;
        writeData($userFile, $users);

        // Respond with success
        echo json_encode(['success' => true]);
        break;

    case 'login':
        $email = $data['email'];
        $password = $data['password'];
        $user = getUserByEmail($email);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Email ou mot de passe incorrect.']);
        }
        break;

    case 'checkSession':
        if (isset($_SESSION['user_id'])) {
            echo json_encode(['loggedIn' => true]);
        } else {
            echo json_encode(['loggedIn' => false]);
        }
        break;

    case 'create':
        $users = readData($userFile);
        $name = $_POST['name'];
        $email = $_POST['email'];
        $image = null;

        if (isset($_FILES['image'])) {
            $targetDir = "uploads/";
            $targetFile = $targetDir . basename($_FILES["image"]["name"]);
            move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile);
            $image = $targetFile;
        }

        $newUser = [
            'id' => uniqid(),
            'name' => $name,
            'email' => $email,
            'image' => $image
        ];

        $users[] = $newUser;
        writeData($userFile, $users);

        echo json_encode(['success' => true]);
        break;

    case 'read':
        echo json_encode(readData($userFile));
        break;

    case 'update':
        $users = readData($userFile);
        $updatedUser = [
            'id' => $_POST['id'],
            'name' => $_POST['name'],
            'email' => $_POST['email'],
            'image' => null
        ];

        foreach ($users as &$user) {
            if ($user['id'] === $updatedUser['id']) {
                $user['name'] = $updatedUser['name'];
                $user['email'] = $updatedUser['email'];

                if (isset($_FILES['image'])) {
                    $targetDir = "uploads/";
                    $targetFile = $targetDir . basename($_FILES["image"]["name"]);
                    move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile);
                    $user['image'] = $targetFile;
                }
                break;
            }
        }

        writeData($userFile, $users);
        echo json_encode(['success' => true]);
        break;

    case 'delete':
        $id = $_GET['id'];
        $users = readData($userFile);
        $users = array_filter($users, function($user) use ($id) {
            return $user['id'] !== $id;
        });

        writeData($userFile, $users);
        echo json_encode(['success' => true]);
        break;

    default:
        echo json_encode(['status' => 'error', 'message' => 'Action non reconnue']);
        break;
}
